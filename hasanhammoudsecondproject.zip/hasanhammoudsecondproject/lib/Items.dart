import 'dart:convert' as convert;
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

const String _baseURL ='https://42130095hasanhammoud.000webhostapp.com/';

class Items {
  int _id;
  String _name;
  int _quantity;
  double _price;
  String _image;
  String _category;
  bool _selected = false;

  Items(this._id, this._name, this._quantity, this._price, this._image, this._category);
  int get ID=> _id;
  String get name => _name;
  int get quantity => _quantity;
  double get price => _price;
  bool get selected => _selected;
  String get image => _image;
  String get Category => _category;
  set selected(bool e) => _selected = e;

  @override
  String toString() {
    return 'PID: $_id Name: $_name\nQuantity: $_quantity Price: \$$_price\nCategory: $_category';
  }
}
List<Items> items = [];
void updateItems(Function(bool success) update) async {
  try{
    final url = Uri.https(_baseURL, 'getItems.php');
    final response = await http.get(url)
        .timeout(const Duration(seconds: 7));
           items.clear();
    if (response.statusCode == 200) {
      final jsonResponse = convert.jsonDecode(response.body);
      for (var row in jsonResponse) {
        Items I = Items(
          int.parse(row['Id']),
          row['name'],
          int.parse(row['quantity']),
          double.parse(row['price']),
          row['Image'],
          row['category']
        );
        items.add(I);
      }
      update(true);
    }
  }
  catch(e) {
    update(false);
  }
}


class ShowSelectedItems extends StatelessWidget {
  const ShowSelectedItems({required this.width, Key? key}) : super(key: key);
  final double width;

  @override
  Widget build(BuildContext context) {
    List<Items> selectedItems = [];
    for (var e in items) {
      if (e.selected) {
        selectedItems.add(e);
      }
    }
    return ListView.builder(
      padding: const EdgeInsets.all(10),
      itemCount: selectedItems.length,
      itemBuilder: (context, index) {
        return Column(children: [
          const SizedBox(height: 10),
          SizedBox(width: width * 0.28),
          Text(selectedItems[index].toString(), style: const TextStyle(fontSize: 18)),
          const SizedBox(height: 10),
          Image.network(selectedItems[index].image,
              height: width * 0.3),
          const SizedBox(height: 10),
        ]);
      },
    );
  }
}


