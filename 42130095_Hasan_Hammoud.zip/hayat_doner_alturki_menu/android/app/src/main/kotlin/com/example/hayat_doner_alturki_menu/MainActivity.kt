package com.example.hayat_doner_alturki_menu

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
