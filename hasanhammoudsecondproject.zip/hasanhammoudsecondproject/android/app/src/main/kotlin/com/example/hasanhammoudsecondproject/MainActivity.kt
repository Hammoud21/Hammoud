package com.example.hasanhammoudsecondproject

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
