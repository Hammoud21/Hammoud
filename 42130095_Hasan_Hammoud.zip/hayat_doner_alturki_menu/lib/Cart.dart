import 'package:flutter/material.dart';
import 'dart:io';

class Cart extends StatefulWidget {
  final double sum;

  Cart({
    Key? key,
    required this.sum,
  }) : super(key: key);

  @override
  State<Cart> createState() => _CartState();
}

class _CartState extends State<Cart> {
  String paymentMethod = 'Cash';
  TextEditingController cashAmountController = TextEditingController();
  TextEditingController visaCardNumberController = TextEditingController();

  Widget build(BuildContext context) {
    double screenWidth = MediaQuery.of(context).size.width;
    if (MediaQuery.of(context).orientation == Orientation.landscape) {
      screenWidth = screenWidth * 0.8;
    }

    return Scaffold(
      backgroundColor: Colors.grey,
      appBar: AppBar(
        backgroundColor: Colors.indigo[600],
        title: Text(
          'The total is: ${widget.sum} dollars',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            color: Colors.yellow,
          ),
        ),
        centerTitle: true,
      ),
      body: Center(
        child: Column(
          children: [
            const SizedBox(height: 10),
            // RadioListTile for Cash
            RadioListTile<String>(
              title: Text('Cash'),
              value: 'Cash',
              groupValue: paymentMethod,
              onChanged: (value) {
                setState(() {
                  paymentMethod = value!;
                });
              },
            ),
            if (paymentMethod == 'Cash')
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: TextField(
                  controller: cashAmountController,
                  keyboardType: TextInputType.number,
                  decoration: InputDecoration(labelText: 'Enter Amount'),
                ),
              ),
            RadioListTile<String>(
              title: Text('Visa'),
              value: 'Visa',
              groupValue: paymentMethod,
              onChanged: (value) {
                setState(() {
                  paymentMethod = value!;
                });
              },
            ),
            // Show card number field for Visa
            if (paymentMethod == 'Visa')
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: TextField(
                  controller: visaCardNumberController,
                  keyboardType: TextInputType.number,
                  decoration: InputDecoration(labelText: 'Enter Visa Card Number'),
                ),
              ),
            const SizedBox(height: 10),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                  style: ElevatedButton.styleFrom(
                    primary: Colors.indigo[600],
                  ),
                  child: Text(
                    'Back',
                    style: TextStyle(color: Colors.yellow),
                  ),
                ),
                ElevatedButton(
                  onPressed: () {
                    // Restart the application
                    exit(0);
                  },
                  style: ElevatedButton.styleFrom(
                    primary: Colors.green,
                  ),
                  child: Text(
                    'Submit',
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
