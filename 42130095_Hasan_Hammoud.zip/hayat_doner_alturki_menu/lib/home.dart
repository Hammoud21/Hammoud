import 'package:flutter/material.dart';
import 'item.dart';
import 'Cart.dart';

class Home extends StatefulWidget {
  const Home({super.key});

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  double _sum =0;
  bool _showSelected = false;


  @override
  Widget build(BuildContext context) {
    double screenWidth = MediaQuery.of(context).size.width;
    if (MediaQuery.of(context).orientation == Orientation.landscape) {
      screenWidth = screenWidth * 0.8;
    }

    return Scaffold(
      backgroundColor: Colors.grey ,
        appBar: AppBar(
          actions: [
        Tooltip(
        message: 'Reset selection',
            child: IconButton(
              onPressed: () {
                setState(() {
                  _sum = 0;
                  for (var e in items) {
                    e.selected = false;
                  }
                  _showSelected = false;
                });
              },
              icon: const Icon(
                Icons.restore,
              ),
            )),],
          backgroundColor: Colors.indigo[600],
          title: Text('Hayat Doner AlTurki',
            style: TextStyle(
              fontWeight: FontWeight.bold,
              color: Colors.yellow,
            ),
          ),
          centerTitle: true,
        ),

        body:
        ListView.builder(
          itemCount: items.length,
          itemBuilder: (context, index) {
            return Column(children: [
              Row(children: [
                SizedBox(width: screenWidth * 0.24),
                Checkbox(
                    value: items[index].selected,
                    onChanged: (e) {
                      items[index].selected = e as bool;
                      if (items[index].selected) {
                        _sum += items[index].price;
                      } else {
                        _sum -= items[index].price;
                      }
                      setState(() {});
                    }),
                Text(items[index].toString()),
              ]),
              Image.network(items[index].image,
                  height: screenWidth * 0.3),
            ]);
          },
        ),
        floatingActionButton: FloatingActionButton(
        onPressed: () {
      Navigator.of(context).push(
          MaterialPageRoute(builder: (context) =>  Cart(
            sum: _sum,
          ))
      );
    },
    child: Icon(Icons.shopping_cart_outlined)
    ),



    );
  }
}
